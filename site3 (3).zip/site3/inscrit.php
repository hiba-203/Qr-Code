<?php
session_start();
$_SESSION['mess'] = "";
$_SESSION['alert'] = "";
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "Parkigdena"; 

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérification de la connexion à la base de données
if ($conn->connect_error) {
    die("La connexion a échoué : " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $mdp = $_POST['mdp'];
    $tel = $_POST['tel'];
    
    // Vérification que tous les champs sont remplis
    if (empty($nom) || empty($prenom) || empty($email) || empty($mdp) || empty($tel)) {
        $_SESSION['mess'] = "Tous les champs doivent être remplis.";
    } else {
        // Vérifier si l'email existe déjà
        $stmt = $conn->prepare("SELECT email_cl FROM client WHERE email_cl = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $_SESSION['mess'] = "Cet email est déjà utilisé. Veuillez en choisir un autre.";
        } else {
            // Préparation de l'insertion
            $stmt = $conn->prepare("INSERT INTO client (nom_cl, prenom_cl, email_cl, mdp_cl, tel_cl) VALUES (?, ?, ?, ?, ?)");
            if ($stmt === false) {
                $_SESSION['mess'] = "Erreur lors de la préparation de la requête : " . $conn->error;
            } else {
                // Lier les paramètres à la requête préparée
                $stmt->bind_param("ssssi", $nom, $prenom, $email, $mdp ,$tel);

                // Exécution de la requête et gestion des erreurs
                if ($stmt->execute()) {
                    $_SESSION['alert'] = "Inscription réussie !";
                } else {
                    $_SESSION['mess'] = "Erreur lors de l'inscription : " . $stmt->error;
                }
            }
        }
        $stmt->close();
    }
}

$conn->close();
header("Location: index.php#about"); // Redirection vers la section inscription
exit();
?>