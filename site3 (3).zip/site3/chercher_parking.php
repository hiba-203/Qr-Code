<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "parkigdena";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

if (!isset($_SESSION['utilisateur'])) {
    header("Location: index.php#seconnecter");
    exit();
}

$nom_client = $_SESSION['utilisateur'];

// Récupérer l'ID du client
$requete_utilisateur = "SELECT id_cl FROM client WHERE email_cl = ?";
$stmt_utilisateur = $conn->prepare($requete_utilisateur);
$stmt_utilisateur->bind_param("s", $nom_client);
$stmt_utilisateur->execute();
$result_utilisateur = $stmt_utilisateur->get_result();
$row_utilisateur = $result_utilisateur->fetch_assoc();
$id_utilisateur = $row_utilisateur['id_cl'] ?? null;

$parkings = [];
$recherche = isset($_GET['recherche']) ? trim($_GET['recherche']) : '';

// Pagination
$parkings_par_page = 2;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int) $_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $parkings_par_page;

// Préparer la requête principale selon recherche ou pas
if ($recherche !== '') {
    $like = "%$recherche%";
    // On compte le total des résultats
    $stmt_count = $conn->prepare("SELECT COUNT(*) as total FROM parking WHERE ville LIKE ? OR nom_park LIKE ?");
    $stmt_count->bind_param("ss", $like, $like);
    $stmt_count->execute();
    $result_count = $stmt_count->get_result();
    $total_parkings = $result_count->fetch_assoc()['total'];

    // On récupère les résultats paginés
    $stmt = $conn->prepare("SELECT * FROM parking WHERE ville LIKE ? OR nom_park LIKE ? LIMIT ? OFFSET ?");
    $stmt->bind_param("ssii", $like, $like, $parkings_par_page, $offset);
} else {
    // Pas de recherche
    $stmt_count = $conn->prepare("SELECT COUNT(*) as total FROM parking");
    $stmt_count->execute();
    $result_count = $stmt_count->get_result();
    $total_parkings = $result_count->fetch_assoc()['total'];

    $stmt = $conn->prepare("SELECT * FROM parking LIMIT ? OFFSET ?");
    $stmt->bind_param("ii", $parkings_par_page, $offset);
}

$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $parkings[] = $row;
}

// Calcul du nombre total de pages
$total_pages = ceil($total_parkings / $parkings_par_page);

function buildUrl($page, $recherche) {
    $url = "?page=" . $page;
    if ($recherche !== '') {
        $url .= "&recherche=" . urlencode($recherche);
    }
    return $url;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Liste des parkings avec pagination</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet" />
    
    <style>
        /* Ton style précédent, plus styles pagination */
        body {
            margin: 0; padding: 0;
            font-family: 'Open Sans', sans-serif;
            background: url('image/park.png') no-repeat center center fixed;
            background-size: cover;
            display: flex; flex-direction: column; align-items: center;
            min-height: 100vh;
            animation: zoomBg 18s infinite alternate ease-in-out;
            color: white;
        }
        @keyframes zoomBg {
            from { background-size: 100%; }
            to { background-size: 110%; }
        }
        body::before {
            content: "";
            position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: -1;
        }
        .navbar {
            width: 100%;
            background-color: rgba(13, 20, 16, 0.7);
            padding: 15px 30px;
            display: flex; justify-content:space-around; align-items: center;
            position: fixed; top: 0; left: 0; right: 0;
            z-index: 1000;
        }
        .welcome {
            font-weight: bold;
            font-size: 1.4rem;
            display: flex; align-items: center;
        }
        .user-photo {
            width: 50px; height: 50px; margin-right: 20px;
            border-radius: 50%; object-fit: contain;
        }
        .nav-links a {
            color: white;
            font-weight: bold;
            text-decoration: none;
            margin-left: 20px;
            font-size: 1.1rem;
            padding: 8px 15px;
            border-radius: 8px;
            transition: background 0.3s;
        }
        .nav-links a:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }
        
       
        .parking-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            max-width: 1000px;
            margin: 45px auto 60px;
            width: 90%;
        }
        .parking {
            background-color: white;
            color: black;
            padding: 20px;
            margin: 15px;
            width: 30%;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
            text-align: center;
            transition: transform 0.2s ease-in-out;
        }
        .parking:hover {
            transform: translateY(-5px);
        }
        .btn-reserver {
            background-color: green;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 10px;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s;
        }
        .btn-reserver:hover {
            background-color: darkgreen;
        }
        .disponible {
            color: green;
            font-weight: bold;
        }
        .indisponible {
            color: red;
            font-weight: bold;
        }
        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 40px;
            gap: 20px;
        }
        .pagination a, .pagination span {
            background-color: rgba(157, 237, 191, 0.7);
            color: white;
            padding: 10px 18px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            font-size: 1.1rem;
            cursor: pointer;
            user-select: none;
            transition: background-color 0.3s;
        }
        .pagination a:hover {
            background-color: #4259f3;
        }
        .pagination .disabled {
            opacity: 0.4;
            cursor: default;
        }
        @media(max-width: 900px) {
            .parking {
                width: 45%;
            }
            .search-bar {
                width: 90%;
                margin-top: 90px;
            }
        }
        @media(max-width: 500px) {
            .parking {
                width: 90%;
            }
        }
.search-bar {
    margin: 12px auto 4px;
    max-width: 600px;
    display: flex;
    align-items: center;
    gap: 12px;
    background: rgba(223, 226, 244, 0.7); /* très léger fond pour la forme */
    padding: 10px 20px;
    border-radius: 30px;
    box-shadow: 0 4px 12px rgba(66, 89, 243, 0.7);
    backdrop-filter: blur(12px);
    transition: box-shadow 0.3s ease;
}

.search-bar:hover {
    box-shadow: 0 6px 20px rgba(66, 89, 243, 0.9);
}

.search-bar input[type="text"] {
    flex: 1;
    font-size: 1.1rem;
    padding: 12px 25px;
    border: none;
    border-radius: 30px;
    outline: none;
    background: transparent;  /* plus de fond blanc */
    color: white;
    
    transition: box-shadow 0.3s ease;
}

.search-bar input[type="text"]::placeholder {
    color: rgba(255, 255, 255, 0.7);
}



.search-bar button {
    background-color: transparent;
    border: none;
    color: #4259f3;
    font-size: 1.8rem;
    cursor: pointer;
    padding: 0 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: color 0.3s ease, transform 0.2s ease;
}

.search-bar button:hover {
    color: #2c3ab6;
    transform: scale(1.2);
}

/* Responsive */
@media (max-width: 500px) {
    .search-bar {
        max-width: 90vw;
        padding: 8px 15px;
    }
    .search-bar input[type="text"] {
        font-size: 1rem;
        padding: 10px 15px;
    }
    .search-bar button {
        font-size: 1.5rem;
        padding: 0 10px;
    }
}


    </style>
</head>
<body>

<div class="navbar">
    <div class="welcome">
        <img src="image/logo1.png" alt="Avatar" class="user-photo" />
        Bienvenue dans votre espace !

    </div>
    <div class="nav-links">
         <a href="voir.php"><i class="fa-solid fa-history"></i>
 Mes réservations</a>
    <a href="update.php"><i class="fas fa-user-edit"></i> Modifier mon profil</a>
    <a href="avis.php"><i class="fas fa-star"></i> Donner un avis</a>
    <a href="index.php"><i class="fas fa-sign-out-alt"></i> Se déconnecter</a>
</div>

</div>

<form method="GET" action="" class="search-bar" style="text-align:center; margin: 100px 0 20px;">
    <input 
        type="text" 
        name="recherche" 
        placeholder="Rechercher un parking par ville ou nom..." 
        value="<?php echo htmlspecialchars($recherche); ?>" 
        style="padding: 10px; width: 300px; border-radius: 5px; border: none; font-size: 1rem;"
    />
    <button type="submit"><i class="fas fa-search"></i></button>

    </button>
</form>




<!--afficher msg dispo ou nn-->
<div class="parking-container">
    <?php if (count($parkings) > 0): ?>
        <?php foreach ($parkings as $row):
            $id_park = (int)$row['id_park'];

            // Vérifier le nombre de places de ce parking
            $sql_places = "SELECT COUNT(*) AS total_places FROM place WHERE id_park = ?";
            $stmt_places = $conn->prepare($sql_places);
            $stmt_places->bind_param("i", $id_park);
            $stmt_places->execute();
            $result_places = $stmt_places->get_result();
            $data_places = $result_places->fetch_assoc();
            $total_places = (int)$data_places['total_places'];
            $stmt_places->close();
        ?>
            <div class="parking">
                <h3><?php echo htmlspecialchars($row['nom_park']); ?></h3>
                <p><strong>Ville :</strong> <?php echo htmlspecialchars($row['ville']); ?></p>
                <p><strong>Adresse :</strong> <?php echo htmlspecialchars($row['adresse']); ?></p>
                <p><strong>Description :</strong> <?php echo htmlspecialchars($row['description']); ?></p>
                <p><strong>Prix :</strong> <?php echo htmlspecialchars($row['prix']); ?> DT / 2 heures</p>

                <?php if ($row['active'] != 1): ?>
                    <p class="indisponible">Non disponible</p>
                <?php elseif ($total_places == 0): ?>
                    <p class="indisponible">Aucune place disponible</p>
                <?php else: ?>
                    <p class="disponible">Disponible</p>
                    <a href="bienvenu.php?id_park=<?php echo $id_park; ?>" class="btn-reserver">Chercher une place</a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="color: white; text-align: center; width: 100%;">Aucun parking trouvé.</p>
    <?php endif; ?>
</div>






<div class="pagination">
    <!-- Bouton Précédent -->
    <?php if ($page > 1): ?>
        <a href="<?php echo buildUrl($page - 1, $recherche); ?>" aria-label="Page précédente">&laquo; Précédent</a>
    <?php else: ?>
        <span class="disabled">&laquo; </span>
    <?php endif; ?>

    <!-- Numéro page courante -->
    <span> <?php echo $page; ?> / <?php echo $total_pages; ?></span>

    <!-- Bouton Suivant -->
    <?php if ($page < $total_pages): ?>
        <a href="<?php echo buildUrl($page + 1, $recherche); ?>" aria-label="Page suivante">Suivant &raquo;</a>
    <?php else: ?>
        <span class="disabled"> &raquo;</span>
    <?php endif; ?>
</div>

</body>
</html>
