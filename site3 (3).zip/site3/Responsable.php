<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "parkigdena";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

if (!isset($_SESSION['utilisateur'])) {
    header("Location: index.php#seconnecter");
    exit();
}

$mail_respo = $_SESSION['utilisateur'];

// Total clients
$requete_nbr_clients = "SELECT COUNT(*) AS total_clients FROM client";
$result_clients = $conn->query($requete_nbr_clients);
$row_clients = $result_clients->fetch_assoc();
$total_clients = $row_clients['total_clients'];

// Total parkings
$requete_parkings = "SELECT COUNT(*) AS total_parkings FROM parking";
$result_parkings = $conn->query($requete_parkings);
$row_parkings = $result_parkings->fetch_assoc();
$total_parkings = $row_parkings['total_parkings'];

// Réservations par mois pour l'année en cours
$annee_courante = date('Y');
$requete_reservations_mois = "
    SELECT 
        MONTH(date_reserv) AS mois, 
        COUNT(*) AS total
    FROM réservation
    WHERE YEAR(date_reserv) = $annee_courante
    GROUP BY mois
    ORDER BY mois
";

$result_reservations_mois = $conn->query($requete_reservations_mois);

// Initialiser un tableau pour 12 mois à 0
$reservations_par_mois = array_fill(1, 12, 0);

if ($result_reservations_mois) {
    while ($row = $result_reservations_mois->fetch_assoc()) {
        $mois = (int)$row['mois'];
        $reservations_par_mois[$mois] = (int)$row['total'];
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Statistiques améliorées</title>
    
    <!-- FontAwesome & Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet" />
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        /* Styles globaux */
        body {
            margin: 0; padding: 0;
            font-family: 'Open Sans', sans-serif;
            background: url('image/park.png') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            animation: zoomBg 18s infinite alternate ease-in-out;
            color: white;
        }
        @keyframes zoomBg {
            from { background-size: 100%; }
            to { background-size: 110%; }
        }
        body::before {
            content: "";
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: -1;
        }
        
        /* Navbar */
        .navbar {
            width: 100%;
            background-color: rgba(13, 20, 16, 0.7);
            padding: 15px 10px;
            box-sizing: border-box;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .welcome {
            font-weight: bold;
            font-size: 1.4rem;
            display: flex;
            align-items: center;
        }
        .user-photo {
            width: 50px;
            height: 50px;
            margin-right: 10px;
            border-radius: 50%;
            object-fit: contain;
        }
        .nav-links {
            display: flex;
            flex-wrap: nowrap;
        }
        .nav-links a {
            color: white;
            font-weight: bold;
            text-decoration: none;
            margin-left: 15px;
            font-size: 1rem;
            padding: 6px 12px;
            border-radius: 8px;
            transition: background 0.3s;
            white-space: nowrap;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .nav-links a:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        /* Cartes statistiques */
        .stats-container {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin: 40px 0 10px;
            flex-wrap: wrap;
        }
        .stat-card {
            background: rgba(223, 245, 249, 0.85);
            color: rgb(27, 23, 23);
            border-radius: 16px;
            padding: 30px 40px;
            width: 280px;
            box-shadow: 0 8px 20px rgba(240, 234, 234, 0.7);
            text-align: center;
            position: relative;
            font-weight: 600;
            font-size: 1.3rem;
            margin-bottom: 25px;
            user-select: none;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 14px 30px rgba(0, 0, 0, 0.85);
        }
        .stat-icon {
            font-size: 3.6rem;
            margin-bottom: 12px;
            color: #0ae588;
        }
        .stat-label {
            font-size: 1.25rem;
            margin-top: 8px;
            font-weight: 600;
            color: #333;
        }

        /* Carte graphique */
        .chart-card {
            background: rgba(223, 245, 249, 0.85);
            border-radius: 16px;
            padding: 24px 28px;
            margin-bottom: 60px;
            color: rgb(27, 23, 23);
            box-shadow: 0 8px 20px rgba(240, 234, 234, 0.7);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(211, 55, 55, 0.1);
            max-width: 410px;
            width: 90vw;
            user-select: none;
        }
        .chart-card h3 {
            text-align: center;
            margin-bottom: 25px;
        }


.logout-wrapper {
  position: relative;
  display: flex;
  align-items: center;
  gap: 12px;
}

#alarm-icon i {
    color: black;
    cursor: pointer;
    transition: color 0.3s;
  }
  #alarm-icon.active i {
    color: red; /* Couleur quand actif */
  }
.dropdown {
  position: relative;
  display: inline-block;
}
.nav-links a:hover {
  background-color: #444;
  color: #00d1b2; /* une touche de couleur turquoise */
}
.dropdown a {
  text-decoration: none;
  color: white;
  padding: 10px;
  display: inline-block;
}

/* Contenu du menu */
.dropdown-content {
  display: none;
  position: absolute;
  top: 100%;
  left: 0;
  background-color: #333;
  min-width: 180px;
  border-radius: 8px;
  box-shadow: 0px 8px 16px rgba(0,0,0,0.3);
  overflow: hidden;
  z-index: 1;
  transition: opacity 0.3s ease;
}

/* Liens dans le sous-menu */
.dropdown-content a {
  color: white;
  padding: 12px 16px;
  display: block;
  transition: background-color 0.2s;
}

/* Hover des liens dans le sous-menu */
.dropdown-content a:hover {
  background-color: #555;
}

/* Affichage au survol */
.dropdown:hover .dropdown-content {
  display: block;
}





    </style>
</head>
<body>

<div class="navbar">
    <div class="container">
        <div class="welcome">
            <img src="image/logo1.png" alt="Avatar" class="user-photo" />
            Bienvenue, <i class="fas fa-hand-peace"></i>
        </div>
       <div class="nav-links">
 <div class="dropdown">
  <a href="#"><i class="fa fa-sync"></i>
 Gérer les places</a>
  <div class="dropdown-content">
    <a href="gérer.resp.php">Ajouter une place</a>
    <a href="gerer_place.php">Modifier une Place</a>
      <a href="gerer_place.php">Désactiver une Place</a>
  </div>
</div>
  <a href="clients.php"><i class="fas fa-users"></i> Mes clients</a>
  <a href="reservations.php"><i class="fas fa-calendar-check"></i> Réservations</a>
  <a href="update.php"><i class="fas fa-user-edit"></i>Profil</a>
  <a href="index.php"><i class="fas fa-power-off"></i> Déconnexion</a>
  <a href="#"><i class="fa-regular fa-bell"></i></a> <!-- Icône cloche alarme -->



</div>

    </div>
</div>

<!-- Cartes chiffres clients et parkings -->
<div class="stats-container">
    <div class="stat-card">
        <i class="fas fa-users stat-icon"></i>
        <div id="clients-count" class="stat-number">0</div>
        <div class="stat-label">Clients inscrits</div>
    </div>
    <div class="stat-card">
        <i class="fas fa-parking stat-icon"></i>
        <div id="parkings-count" class="stat-number">0</div>
        <div class="stat-label">Parkings disponibles</div>
    </div>
</div>

<!-- Graphique des réservations par mois -->
<div class="chart-card">
    <h3>Réservations par mois en <?= $annee_courante ?></h3>
    <canvas id="statsChart" width="700" height="400"></canvas>
</div>

<script>
    // Animation compteur simple
    function countUp(elementId, targetNumber, duration = 1500) {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            document.getElementById(elementId).textContent = Math.floor(progress * targetNumber);
            if (progress < 1) {
                window.requestAnimationFrame(step);
            } else {
                document.getElementById(elementId).textContent = targetNumber;
            }
        };
        window.requestAnimationFrame(step);
    }

    // Lancer l'animation pour clients et parkings
    countUp('clients-count', <?= $total_clients ?>);
    countUp('parkings-count', <?= $total_parkings ?>);

    // Graphique Chart.js
    const ctx = document.getElementById('statsChart').getContext('2d');
    const moisLabels = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'];
    const reservationsData = <?= json_encode(array_values($reservations_par_mois)) ?>;

    const statsChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: moisLabels,
            datasets: [{
                label: `Réservations par mois (<?= $annee_courante ?>)`,
                data: reservationsData,
                backgroundColor: '#0ae588',
                borderColor: '#057a3f',
                borderWidth: 1,
                borderRadius: 8,
                maxBarThickness: 45,
                minBarLength: 3,
                hoverBackgroundColor: '#05a64d',
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1,
                        color: '#333',
                        font: { size: 14 }
                    },
                    grid: {
                        color: '#d5d5d5'
                    }
                },
                x: {
                    ticks: {
                        color: '#333',
                        font: { size: 14 }
                    },
                    grid: {
                        display: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    enabled: true,
                    backgroundColor: '#0ae588',
                    titleColor: '#000',
                    bodyColor: '#000'
                }
            }
        }
    });
</script>
<script>
  const alarmIcon = document.getElementById('alarm-icon');
  alarmIcon.addEventListener('click', function(e) {
    e.preventDefault(); // empêche le lien de naviguer
    this.classList.toggle('active');
  });
</script>

</body>
</html>
