<?php
session_start();
//$_SESSION['mess']='';
include('connexion.php');
?>


<!DOCTYPE HTML>
<!--
	Dimension by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
	
		<title>ParkiGdena</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="is-preload">

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Header -->
					<header id="header">
						<div class="logo">
                        <img src="image/logo1.png" alt="Logo" style="width: 80px; height: auto; margin-top: -5px;">

						</div>
						<div class="content">
							<div class="inner">
								<h1>ParkiGdena</h1>
								<p>Votre véhicule mérite le meilleur, stationnez avec confiance.</p>
							</div>
						</div>
						<nav>
							<ul>
								<li><a href="#Apropos">A propos</a></li>
								<li><a href="#seconnecter">se connecter</a></li>
								<li><a href="#about">s'inscrire</a></li>
								
                                
								<!--<li><a href="#elements">Elements</a></li>-->
							</ul>
						</nav>
					</header>

				<!-- Main -->
					<div id="main">

						<!-- Intro -->
							<article id="Apropos">
								<h2 class="major">A propos</h2>
								<span class="image main"><img src="" alt="" /></span>
								<h3><a href="#work">Bienvenue sur Parkigdena, votre solution de stationnement intelligente !</a>.</h3>
								<p>Chez Parkigdena, nous avons créé un espace de stationnement moderne, sécurisé et pratique pour répondre à tous vos besoins au Bourgo Mall. Que vous soyez un résident, un travailleur ou simplement un visiteur, notre parking est conçu pour vous offrir une expérience fluide et sans tracas. Grâce à notre plateforme en ligne, vous pouvez facilement réserver votre place, suivre la disponibilité en temps réel et profiter d'un service rapide et fiable. Découvrez une nouvelle façon de vous garer, avec Parkigdena au Bourgo Mall, là où votre confort est notre priorité.

</p>
							</article>

					<!-- Se connecter -->
<article id="seconnecter">
    <h2 class="major">Se connecter</h2>

    <!-- Affichage du message d'erreur -->
    <?php 
    if (!empty($_SESSION['message'])) : 
    ?>
        <div style="color: red; font-weight: bold; margin-bottom: 10px;">
            <?php 
            echo $_SESSION['message']; 
            unset($_SESSION['message']); // Supprimer le message après affichage
            ?>
        </div>
    <?php endif; ?>

    <form method="post" action="connecter.php">
    <div class="fields">

        <!-- Choix du rôle -->
        <div class="field">
            <label for="role">Se connecter en tant que :</label>
            <select name="role" id="role" onchange="toggleFields()" required>
                <option value="">-- Choisir un rôle --</option>
                <option value="client">Client</option>
                <option value="responsable">Responsable</option>
            </select>
        </div>


<!-- Champ Email (commun) -->
<div class="field half">
    <label for="email">Email</label>
    <input type="email" name="mail" id="email" placeholder="exemple@domaine.com" required />
</div>

        <!-- Mot de passe (commun) -->
        <div class="field half">
            <label for="password">Mot de passe</label>
            <div class="password-container">
                <input type="password" name="password" id="password" required />
                <span class="eye-icon" onclick="togglePassword('password')">
                    <i class="fas fa-eye"></i>
                </span>
            </div>
        </div>
    </div>




        
        <ul class="actions">
            <li><input type="submit" value="Se connecter" class="primary" /></li>
        </ul>
    </form>
</article>


</script>
<style>
    .password-container {
        position: relative;
    }

    .eye-icon {
        position: absolute;
        right: 10px;
        top: 12px;
        cursor: pointer;
    }

    .eye-icon-slash {
        font-size: 20px;
    }

    .eye-icon {
        font-size: 20px;
    }
    
</style>


<!--si'nscrireeeeeeeee-->

<article id="about">
    <h2 class="major">S'inscrire</h2>
    <div>
    <?php 
    if (!empty($_SESSION['mess'])) : 
    ?>
        <div style="color: red; font-weight: bold; margin-bottom: 10px;">
            <?php 
            echo $_SESSION['mess']; 
            unset($_SESSION['mess']); // Supprimer le message après affichage
            ?>
        </div>
    <?php endif; ?>
    <?php 
    if (!empty($_SESSION['alert'])) : 
    ?>
        <div style="color: green; font-weight: bold; margin-bottom: 10px;">
            <?php 
            echo $_SESSION['alert']; 
            unset($_SESSION['alert']); // Supprimer le message après affichage
            ?>
        </div>
    <?php endif; ?>
   <!-- <input type="checkbox" name="conditions" id="conditions">
    <label for="conditions">J'accepte les <a href="conditions.php" target="_blank">conditions d'utilisation</a></label>-->
</div>


    <!-- Zone d'affichage des messages de validation -->
    <div id="password-message" class="message">
        <?php
        
        if (isset($_SESSION['message'])) {
            // Affichage du message
            $message_type = isset($_SESSION['message_type']) ? $_SESSION['message_type'] : 'error';
            $message_class = ($message_type == 'error') ? 'error' : 'success';
            echo "<p class=\"$message_class\">" . $_SESSION['message'] . "</p>";

            // Réinitialiser le message après affichage
            unset($_SESSION['message']);
            unset($_SESSION['message_type']);
        }
        ?>
    </div>

   <form method="post" action="inscrit.php" onsubmit="return validatePassword();">
        <div class="fields">
            <div class="field half">
                <label for="nom">Nom</label>
                <input type="text" name="nom" id="nom" required />
            </div>
            <div class="field half">
                <label for="prenom">Prénom</label>
                <input type="text" name="prenom" id="prenom" required />
            </div>
            <div class="field half">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" required />
            </div>
           <div class="field half">
    <label for="tel">Téléphone</label>
    <input type="tel" name="tel" id="tel" pattern="[0-9]{8}" maxlength="8" required 
           
           oninput="this.value = this.value.replace(/[^0-9]/g, '');" />


</div>


            <div class="field half">
                <label for="mdp">Mot de passe</label>
                <div class="password-container">
                    <input type="password" name="mdp" id="mdp" required onkeyup="validatePassword();" />
                    <span class="eye-icon" onclick="togglePassword('mdp')">
                        <i class="fas fa-eye"></i>
                    </span>
                </div>
            </div>
            <div class="field half">
                <label for="confirm">Confirmer le mot de passe</label>
                <div class="password-container">
                    <input type="password" name="confirm" id="confirm" required onkeyup="validatePassword();" />
                    <span class="eye-icon" onclick="togglePassword('confirm')">
                        <i class="fas fa-eye"></i>
                    </span>
                </div>
            </div>
           
          
            

        </div>
        <ul class="actions">
            <li><input type="submit" value="S'inscrire" class="primary" /></li>
            <li><input type="reset" value="Annuler" /></li>
        </ul>
    </form>
</article>


<script>

function validatePassword() {
    const pass = document.getElementById("mdp").value;
    const confirm = document.getElementById("confirm").value;
    if (pass !== confirm) {
        alert("Les mots de passe ne correspondent pas !");
        return false;
    }
    return true;
}

function togglePassword(id) {
    const input = document.getElementById(id);
    input.type = input.type === "password" ? "text" : "password";
}


    // Fonction pour afficher/masquer le mot de passe
    function togglePassword(id) {
        var passwordField = document.getElementById(id);
        var eyeIcon = passwordField.nextElementSibling.querySelector('i');

        // Si le mot de passe est masqué, le rendre visible
        if (passwordField.type === "password") {
            passwordField.type = "text";
            eyeIcon.classList.remove("fa-eye");
            eyeIcon.classList.add("fa-eye-slash");
        } else {
            // Si le mot de passe est visible, le masquer
            passwordField.type = "password";
            eyeIcon.classList.remove("fa-eye-slash");
            eyeIcon.classList.add("fa-eye");
        }
    }

    // Fonction de validation du mot de passe
    function validatePassword() {
        var password = document.getElementById('mdp').value;
        var confirmPassword = document.getElementById('confirm').value;
        var message = document.getElementById('password-message');
        var regexLower = /[a-z]/;
        var regexUpper = /[A-Z]/;
        var regexDigit = /\d/;
        
        var errors = [];

        // Vérification de la longueur du mot de passe
        if (password.length < 8 ){
            errors.push("Le mot de passe doit contenir au moins 8 caractères.");
        }

        // Vérification de la présence d'une minuscule
        if (!regexLower.test(password)) {
            errors.push("Le mot de passe doit contenir au moins une lettre minuscule.");
        }

        // Vérification de la présence d'une majuscule
        if (!regexUpper.test(password)) {
            errors.push("Le mot de passe doit contenir au moins une lettre majuscule.");
        }

        // Vérification si les mots de passe correspondent
        if (password !== confirmPassword) {
            errors.push("Les mots de passe ne correspondent pas.");
        }

        // Affichage des erreurs ou message de succès
        if (errors.length > 0) {
            message.innerHTML = errors.join("<br>");
            message.classList.remove("valid");
            message.classList.add("invalid");
            return false;  // Empêche la soumission du formulaire si des erreurs existent
        } else {
            message.innerHTML = "Mot de passe valide!";
            message.classList.remove("invalid");
            message.classList.add("valid");
            return true;  // Permet la soumission du formulaire si tout est correct
        }
    }
</script>


<style>
    #password-message {
        margin-top: 10px;
        padding: 10px;
        font-size: 14px;
    }

    .invalid {
        color: red;
        font-weight: bold;
    }

    .valid {
        color: green;
        font-weight: bold;
    }

    .password-container {
        position: relative;
    }

    .eye-icon {
        position: absolute;
        right: 10px;
        top: 12px;
        cursor: pointer;
    }

    .eye-icon-slash {
        font-size: 20px;
    }

    .eye-icon {
        font-size: 20px;
    }
</style>


<!-- <?php
include('connexion.php'); 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $nom = trim($_POST['nom']);
    $email = trim($_POST['email']);
    $commentaire = trim($_POST['commentaire']);

    
    $stmt = $conn->prepare("INSERT INTO avis (nom_cl, email_cl, comment_cl) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nom, $email, $commentaire);

    if ($stmt->execute()) {
        // Avis enregistré avec succès
        $_SESSION['message'] = "Merci pour votre avis !";
    } else {
        // Si l'insertion échoue
        $_SESSION['message'] = "Erreur lors de l'envoi de votre avis. Veuillez réessayer.";
    }

    // Rediriger l'utilisateur vers la page d'accueil après l'insertion
    //header("Location: index.php#lesavis");
   // exit();
}
?>



<article id="lesavis">
    <h2 class="major">Les Avis</h2>

    <div id="formulaire-avis">
        <h3>Donnez votre avis</h3>

       
        <form method="POST" action="#">
            <div class="fields">
                <div class="field half">
                    <label for="nom">Nom</label>
                    <input type="text" name="nom" id="nom" placeholder="Votre nom" required />
                </div>

                <div class="field half">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" placeholder="Votre email" required />
                </div>

                <div class="field">
                    <label for="commentaire">Commentaire</label>
                    <textarea name="commentaire" id="commentaire" placeholder="Votre avis" rows="4" required></textarea>
                </div>

                
    
            </div>

            <ul class="actions">
                <li><input type="submit" value="Envoyer" class="primary" /></li>
                <li><input type="reset" value="Annuler" class="primary" /></li>
                <li><input type="submit" value="Consulter les avis" class="primary" /></li>
            </ul>
        </form>
    </div>
</article>

<style>
    #avis-container {
        margin-top: 20px;
    }

    /* Avis individuel */
    .avis {
        background-color: #f9f9f9;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 15px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .avis:hover {
        transform: scale(1.02);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    /* Nom de l'auteur de l'avis */
    .avis strong {
        font-size: 18px;
        color: #333;
    }

    /* Commentaire */
    .avis p {
        font-size: 16px;
        line-height: 1.5;
        color: #555;
        margin-top: 10px;
    }

</style>




						<!-- Contact -->
							<article id="contact">
								
								<ul class="icons">
									
									<li><a href="#" class="icon brands fa-facebook-f"><span class="label">Facebook</span></a></li>
									<li><a href="#" class="icon brands fa-instagram"><span class="label">Instagram</span></a></li>
									
								</ul>
							</article>

						<!-- Elements -->
							<article id="elements">
								<h2 class="major">Elements</h2>
 
							
									<ul class="actions">
										<li><span class="button primary disabled">Disabled</span></li>
										<li><span class="button disabled">Disabled</span></li>
									</ul>
								</section>


							</article>

					</div>

				
					<footer id="footer">
						<p class="copyright">contact:25814736/75412789</p>
					</footer>

			</div>

			<div id="bg"></div>

		
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>
