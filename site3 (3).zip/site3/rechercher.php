<?php
// Connexion à la base de données et début de session
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "parkigdena";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

if (!isset($_SESSION['utilisateur'])) {
    header("Location: index.php#seconnecter");
    exit();
}

$nom_client = $_SESSION['utilisateur'];

// Récupérer l'ID du client à partir de son email
$requete_utilisateur = "SELECT id_cl FROM client WHERE email_cl = ?";
$stmt_utilisateur = $conn->prepare($requete_utilisateur);
$stmt_utilisateur->bind_param("s", $nom_client);
$stmt_utilisateur->execute();
$result_utilisateur = $stmt_utilisateur->get_result();
$row_utilisateur = $result_utilisateur->fetch_assoc();
$id_utilisateur = $row_utilisateur['id_cl'];


?>

  <!DOCTYPE html>
  <html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@400;700&family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <title>Modifier votre profil</title>
    <style>
      * {
        box-sizing: border-box;
      }
      body {
    margin: 0;
    padding: 0;
    font-family: 'Open Sans', sans-serif;
    background: url('image/park.png') no-repeat center center fixed;
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    flex-direction: column;
   animation: zoomBg 10s infinite alternate ease-in-out;
}
@keyframes zoomBg {
  from {
    background-size: 100%;
  }
  to {
    background-size: 110%;
  }
}



body::before {
    content: "";
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.7); /* noir transparent */
    z-index: -1;
}

          .navbar {
      background-color: rgba(95, 96, 97, 0.7);
      padding: 15px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1000;
  }

  .welcome {
    color: white;
    font-family: 'Roboto', sans-serif; /* Ou la police de votre choix */
    font-size: 1.8rem;
    animation: fadeSlideIn 1.5s ease-out;
    display: flex;
    align-items: center;
    text-decoration: none;
    font-weight: bold;
    text-shadow: 0 0 8px rgba(255, 255, 255, 0.8); /* Légère ombre blanche */
}
  .user-photo {
      width: 50px;  /* Largeur du logo */
      height: 50px; /* Hauteur du logo */
      margin-right: 10px; /* Espacement entre le logo et le texte */
      object-fit: contain; /* Assurer que le logo garde ses proportions */
      border-radius: 50%; /* Si tu veux un logo rond */
  }
  .nav-links {
              display: flex;
              gap: 30px;
              font-family: 'Open Sans', sans-serif;
              
          }
          .navbar {
    background-color: rgba(13, 20, 16, 0.7);
    padding: 15px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
}

          .nav-links a {
              color: white;
              text-decoration: none;
              font-weight: bold;
              font-size: 1.2rem;
              padding: 8px 16px;
              border-radius: 8px;
              transition: background 0.3s;
              font-family: 'Open Sans', sans-serif;
              font-size: auto;
              animation: fadeSlideIn 1.5s ease-out;
          }

          .nav-links a:hover {
              background-color: rgba(255, 255, 255, 0.2);
          }

      .container {
        width: 1000px;
        max-width: 100%;
        background: white;
        border-radius: 15px;
        display: flex;
        overflow: hidden;
        box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        animation: fadeIn 0.8s ease-out both;
      }
      
      .sidebar h2 {
        margin-bottom: 40px;
      }
      .sidebar img {
        width: 200px;
        margin-bottom: 30px;
        margin-top: -30px;
      }
     
      
      @keyframes fadeIn {
        from {
          opacity: 0;
          transform: translateY(20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
    }
    .search-bar {
    width: 700px;
    margin: 40px auto;
    position: relative;
}


        .search-bar input {
            width: 100%;
            padding: 18px 55px 18px 20px;
            font-size: 18px;
            border: 1.5px solid #ccc;
            border-radius: 50px;
            outline: none;
            transition: border-color 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            background-color: #fff;
        }

        .search-bar input:focus {
            border-color: #4259f3;
            box-shadow: 0 4px 12px rgba(66, 89, 243, 0.2);
        }

        .search-bar i {
            position: absolute;
            right: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #666;
            font-size: 20px;
        }
    </style>
  </head>
  
  <body>
<div class = "navbar">
    <div class="nav-links">
         <img src="image/logo1.png" alt="Avatar" class="user-photo">
          <a href="Chercher_parking.php">Chercher et Réservez!</a>
        <a href="update.php">Modifier mon profil</a>
        <a href="avis.php">Donner un avis</a>
        <a href="index.php">Se déconnecter</a>
        
    </div>
</div>
<div class="welcome">
       Bienvenue dans votre espace !
    </div>

<!--
<div class="search-bar">
    <form method="GET" action="chercher_parking.php">
        <input type="text" name="recherche" placeholder="Votre destination...">
        <i class="fas fa-search"></i>
    </form>
</div>

