<?php
$user="root";
$mp="";
$server="localhost";
$db="parkigdena";

$conn=mysqli_connect($server,$user,$mp,$db);
if($conn)
echo"";
else
echo "connexion invalide";


?>