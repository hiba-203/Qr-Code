<?php
session_start();

// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "parkigdena";
$message = "";

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

if (!isset($_SESSION['utilisateur'])) {
    header("Location: index.php#seconnecter");
    exit();
}
$nom_client = $_SESSION['utilisateur'];

$sql = "SELECT * FROM client WHERE email_cl = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $nom_client);
$stmt->execute();
$result = $stmt->get_result();

$email_cl_err = $mdp_cl_err = $tel_cl_err = $nom_cl_err = $prenom_cl_err ='';

if ($row = $result->fetch_assoc()) {
    $nom_cl = $row['nom_cl'];
    $prenom_cl = $row['prenom_cl'];
    $tel_cl = $row['tel_cl'];
    $email_cl = $row['email_cl'];
    $mdp_cl = $row['mdp_cl'];
    $id_cl = $row['id_cl'];
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email_cl = !empty($_POST['email_cl']) ? filter_var(trim($_POST['email_cl']), FILTER_SANITIZE_EMAIL) : '';
    $mdp_cl = !empty($_POST['mdp']) ? trim($_POST['mdp']) : '';
    $tel_cl = !empty($_POST['tel_cl']) ? trim($_POST['tel_cl']) : '';
    $nom_cl = !empty($_POST['nom_cl']) ? trim($_POST['nom_cl']) : '';
    $prenom_cl = !empty($_POST['prenom_cl']) ? trim($_POST['prenom_cl']) : '';


    $valid = true;
if (empty($nom_cl)) {
    $nom_cl_err = "Le nom est requis.";
    $valid = false;
}

if (empty($prenom_cl)) {
    $prenom_cl_err = "Le prénom est requis.";
    $valid = false;
}

if (empty($tel_cl)) {
    $tel_cl_err = "Le téléphone est requis.";
    $valid = false;
} elseif (!preg_match('/^[0-9]{8}$/', $tel_cl)) {
    $tel_cl_err = "Numéro invalide. 8 chiffres requis.";
    $valid = false;
}

    if (empty($email_cl)) {
        $email_cl_err = "L'adresse e-mail est requise.";
        $valid = false;
    } elseif (!filter_var($email_cl, FILTER_VALIDATE_EMAIL)) {
        $email_cl_err = "Format d'e-mail invalide.";
        $valid = false;
    }

    if (empty($mdp_cl)) {
        $mdp_cl_err = "Le mot de passe est requis.";
        $valid = false;
    } elseif (!preg_match('/^(?=.*[a-z])(?=.*[A-Z]).{8,}$/', $mdp_cl)) {
        $mdp_cl_err = "Le mot de passe doit contenir au moins 8 caractères, une lettre majuscule et une minuscule.";
        $valid = false;
    }

    if ($valid) {
        $stmt = $conn->prepare("UPDATE client SET nom_cl = ?, prenom_cl = ?, email_cl = ?, tel_cl = ?, mdp_cl = ? WHERE id_cl = ?");
$stmt->bind_param('sssssi', $nom_cl, $prenom_cl, $email_cl, $tel_cl, $mdp_cl, $id_cl);

        if ($stmt->execute()) {
            $message = "Profil mis à jour avec succès.";
        } else {
            $message = "Erreur lors de la mise à jour du profil.";
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
   
    <title>Modifier votre profil</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: 'Open Sans', sans-serif;
            background: url('image/park.png') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
            animation: zoomBg 10s infinite alternate ease-in-out;
        }
        @keyframes zoomBg {
            from { background-size: 100%; }
            to { background-size: 110%; }
        }
        body::before {
            content: "";
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: -1;
        }
        .navbar {
            background-color: rgba(13, 20, 16, 0.7);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0; left: 0; right: 0;
            z-index: 1000;
        }
        .welcome {
            color: white;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            font-weight: bold;
        }
        .user-photo {
            width: 50px;
            height: 50px;
            margin-right: 10px;
            object-fit: contain;
            border-radius: 50%;
        }
        
        

.nav-links a {
            color: white;
            font-weight: bold;
            text-decoration: none;
            margin-left: 20px;
            font-size: 1.1rem;
            padding: 8px 15px;
            border-radius: 8px;
            transition: background 0.3s;
        }

        .nav-links a:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }
        .container {
    max-width: 1000px; /* ou remplace par 90% si tu veux en pourcentage */
    width: 50%; /* prend toute la largeur possible jusqu'au max-width */
    background:  white;
    border-radius: 15px;
    padding: 40px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    margin: 100px auto; /* centré horizontalement */
}

        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            font-weight: bold;
        }
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
        }
        .form-actions {
            display: flex;
            gap: 10px;
        }
        .btn-next {
            background: #20c997;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        .btn-next:hover {
            background: #17a589;
        }
        .text-danger {
            color: red;
            font-size: 13px;
        }
        .alert {
            background: #d4edda;
            color: #155724;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<div class="navbar">
    <div class="welcome">
        <img src="image/logo1.png" alt="Avatar" class="user-photo">
        Bienvenue dans votre espace !
    </div>
    <div class="nav-links">
        <a href="Chercher_parking.php"><i class="fas fa-search"></i>Chercher et Réserver!</a>
        <a href="voir.php"><i class="fa-solid fa-history"></i>Mes réservations</a>
        <a href="avis.php"><i class="fas fa-star"></i> Donner un avis</a>
        <a href="index.php"><i class="fas fa-sign-out-alt"></i> Se déconnecter</a>
    </div>
</div>

<div class="container">
    <h3>Modifier vos coordonnées</h3>

    <?php if (!empty($message)) echo "<div class='alert'>$message</div>"; ?>

    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="form-group">
             <label>Nom</label>
            <div style="display: flex; align-items: center;">
                <input type="text" name="nom_cl" id="nom_cl" class="form-control"
                       value="<?php echo htmlspecialchars($nom_cl); ?>" readonly>
                <i class="bi bi-pencil-square" style="margin-left: 10px; cursor: pointer;" onclick="enableEdit('nom_cl')"></i>
            </div>
            <small class="text-danger"><?php echo $nom_cl_err; ?></small>
        </div> 


<div class="form-group">
    <label>Prénom</label>
    <div style="display: flex; align-items: center;">
        <input type="text" name="prenom_cl" id="prenom_cl" class="form-control"
               value="<?php echo htmlspecialchars($prenom_cl); ?>" readonly>
        <i class="bi bi-pencil-square" style="margin-left: 10px; cursor: pointer;" onclick="enableEdit('prenom_cl')"></i>
    </div>
    <small class="text-danger"><?php echo $prenom_cl_err; ?></small>
</div>

<div class="form-group">
            <label>Email</label>
            <div style="display: flex; align-items: center;">
                <input type="email" name="email_cl" id="email_cl" class="form-control"
                       value="<?php echo htmlspecialchars($email_cl); ?>" readonly>
                <i class="bi bi-pencil-square" style="margin-left: 10px; cursor: pointer;" onclick="enableEdit('email_cl')"></i>
            </div>
            <small class="text-danger"><?php echo $email_cl_err; ?></small>
        </div>


        <div class="form-group">
            <label>Numéro de téléphone</label>
            <div style="display: flex; align-items: center;">
                <input type="text" name="tel_cl" id="tel_cl" class="form-control"
                       value="<?php echo htmlspecialchars($tel_cl); ?>" readonly>
                <i class="bi bi-pencil-square" style="margin-left: 10px; cursor: pointer;" onclick="enableEdit('tel_cl')"></i>
            </div>
            <small class="text-danger"><?php echo $tel_cl_err; ?></small>
        </div>

       <div class="form-group">
    <label>Nouveau mot de passe</label>
    <div style="display: flex; align-items: center;">
        <input type="password" name="mdp" id="mdp" class="form-control"
               value="<?php echo htmlspecialchars($mdp_cl); ?>" readonly
               pattern="(?=.*[a-z])(?=.*[A-Z]).{8,}"
               title="Le mot de passe doit contenir au moins 8 caractères, une majuscule et une minuscule.">

        <!-- Icône pour activer l'édition -->
        <i class="bi bi-pencil-square" style="margin-left: 10px; cursor: pointer;" onclick="enableEdit('mdp')"></i>

        <!-- Icône œil pour afficher/masquer le mot de passe -->
        <i id="togglePassword" class="bi bi-eye" style="margin-left: 10px; cursor: pointer;" 
           onclick="togglePasswordVisibility()"></i>
    </div>
    <small class="text-danger"><?php echo $mdp_cl_err; ?></small>
</div>

<script>
    function enableEdit(fieldId) {
        const field = document.getElementById(fieldId);
        field.removeAttribute("readonly");
        field.focus();
    }

    function togglePasswordVisibility() {
        const pwdField = document.getElementById('mdp');
        const toggleIcon = document.getElementById('togglePassword');
        if (pwdField.type === "password") {
            pwdField.type = "text";
            toggleIcon.classList.remove('bi-eye');
            toggleIcon.classList.add('bi-eye-slash');
        } else {
            pwdField.type = "password";
            toggleIcon.classList.remove('bi-eye-slash');
            toggleIcon.classList.add('bi-eye');
        }
    }
</script>


        <div class="form-actions">
            <button type="submit" class="btn-next">Enregistrer</button>
         </div>
    </form>
     </div>
</div>









<script>
    function enableEdit(fieldId) {
        document.getElementById(fieldId).removeAttribute("readonly");
        document.getElementById(fieldId).focus();
    }
</script>
</body>
</html>
