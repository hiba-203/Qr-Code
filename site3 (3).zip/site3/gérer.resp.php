<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "parkigdena";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

if (!isset($_SESSION['utilisateur'])) {
    header("Location: index.php#seconnecter");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Statistiques améliorées</title>
    
    <!-- FontAwesome & Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        /* Styles globaux */
        body {
            margin: 0; padding: 0;
            font-family: 'Open Sans', sans-serif;
            background: url('image/park.png') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            animation: zoomBg 18s infinite alternate ease-in-out;
            color: white;
        }
        @keyframes zoomBg {
            from { background-size: 100%; }
            to { background-size: 110%; }
        }
        body::before {
            content: "";
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: -1;
        }
        .navbar {
            width: 100%;
            background-color: rgba(13, 20, 16, 0.7);
            padding: 15px 10px;
            box-sizing: border-box;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .welcome {
            font-weight: bold;
            font-size: 1.4rem;
            display: flex;
            align-items: center;
        }
        .user-photo {
            width: 50px;
            height: 50px;
            margin-right: 10px;
            border-radius: 50%;
            object-fit: contain;
        }
        .nav-links {
            display: flex;
            flex-wrap: nowrap;
        }
        .nav-links a {
            color: white;
            font-weight: bold;
            text-decoration: none;
            margin-left: 15px;
            font-size: 1rem;
            padding: 6px 12px;
            border-radius: 8px;
            transition: background 0.3s;
            white-space: nowrap;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .nav-links a:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .dropdown {
            position: relative;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background-color: #333;
            min-width: 180px;
            border-radius: 8px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.3);
            overflow: hidden;
            z-index: 1;
        }
        .dropdown-content a {
            color: white;
            padding: 12px 16px;
            display: block;
            transition: background-color 0.2s;
        }
        .dropdown-content a:hover {
            background-color: #555;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }

        #alarm-icon i {
            color: white;
            cursor: pointer;
            transition: color 0.3s;
        }
        #alarm-icon.active i {
            color: red;
        }

        h1 {
            text-align: center;
            margin: 30px 0;
        }

        .btn {
            padding: 8px 14px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            cursor: pointer;
            margin-bottom: 15px;
        }
        .btn:hover {
            background-color: #0056b3;
        }

        table {
            width: 70%;
            border-collapse: separate;
            background-color: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            border: 2px solid #004080;
            margin-bottom: 40px;
            border-radius: 12px;
        }
        th, td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #ddd;
            color: black;
        }
        .actions i {
            cursor: pointer;
            margin: 0 5px;
            font-size: 18px;
        }
        .actions .edit {
            color: #28a745;
        }
        .actions .disable {
            color: #dc3545;
        }
        .header-actions {
            width: 70%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 40px auto;
            padding: 10px 0;
        }
        .header-actions h1 {
            margin: 0;
            font-size: 24px;
            color: white;
        }
        .btn i {
            margin-right: 5px;
        }
    </style>
</head>
<body>

<div class="navbar">
    <div class="container">
        <div class="welcome">
            <img src="image/logo1.png" alt="Avatar" class="user-photo" />
            Bienvenue, <i class="fas fa-hand-peace"></i>
        </div>
        <div class="nav-links">
            <div class="dropdown">
                <a href="#"><i class="fa fa-sync"></i>
 Prolongation</a>
                <div class="dropdown-content">
                    <a href="gérer.resp.php">Gérer Parking</a>
                    <a href="gerer_place.php">Gérer Place</a>
                </div>
            </div>
            <a href="clients.php"><i class="fas fa-users"></i> Mes clients</a>
            <a href="reservations.php"><i class="fas fa-calendar-check"></i> Réservations</a>
            <a href="update.php"><i class="fas fa-user-edit"></i> Profil</a>
            <a href="logout.php"><i class="fas fa-power-off"></i> Déconnexion</a>
            <a href="#" id="alarm-icon"><i class="fa-regular fa-bell"></i></a>
        </div>
    </div>
</div>

<script>
  const alarmIcon = document.getElementById('alarm-icon');
  if (alarmIcon) {
    alarmIcon.addEventListener('click', function(e) {
      e.preventDefault();
      this.classList.toggle('active');
    });
  }
</script>

<div class="header-actions">
    
    <a href="ajouter_parking.php" class="btn"><i class="fas fa-plus"></i> Ajouter Parking</a>
</div>

<table>
  <thead>
    <tr>
      <th>Nom</th>
      <th>Emplacement</th>
      <th>État</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
   <?php
$sql = "SELECT * FROM parking";
$result = $conn->query($sql);

if ($result === false) {
    echo "<tr><td colspan='4'>Erreur lors de la récupération des données.</td></tr>";
} elseif ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $nom = htmlspecialchars($row['nom_park']);
        $ville = htmlspecialchars($row['ville']);
        $etat = ($row['dispo'] == 1) ? "Actif" : "Désactivé";
        $id = (int)$row['id_park']; // casting pour sécurité

        echo "<tr>";
        echo "<td>$nom</td>";
        echo "<td>$ville</td>";
        echo "<td>$etat</td>";
        echo "<td class='actions'>";
        
        // Lien modifier
        echo "<a href='modifier_parking.php?id=$id' title='Modifier'><i class='fas fa-edit edit'></i></a> ";

        // Icône toggle selon dispo
        if ($row['dispo'] == 1) {
            // Parking actif → bouton désactiver (toggle-on vert)
            echo "<a href='desactiver_parking.php?id=$id' title='Désactiver' onclick=\"return confirm('Désactiver ce parking ?');\">
                    <i class='fas fa-toggle-on' style='color:green; font-size:20px;'></i>
                  </a>";
        } else {
            // Parking désactivé → bouton activer (toggle-off rouge)
            echo "<a href='activer_parking.php?id=$id' title='Activer' onclick=\"return confirm('Activer ce parking ?');\">
                    <i class='fas fa-toggle-off' style='color:red; font-size:20px;'></i>
                  </a>";
        }

        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='4'>Aucun parking trouvé.</td></tr>";
}
?>

  </tbody>
</table>

</body>
</html>
