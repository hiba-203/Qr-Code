<?php
session_start();
include("connexion.php");

// Vérifie que c’est bien une requête AJAX 
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    header("HTTP/1.0 403 Forbidden");
    exit();
}

// Récupérer les données envoyées
$date_reservation = $_POST['date'] ?? null;
$heure_entree = $_POST['entry-time'] ?? null;
$heure_sortie = $_POST['exit-time'] ?? null;
$id_park = $_POST['id_park'] ?? null;

if (!$date_reservation || !$heure_entree || !$heure_sortie || !$id_park) {
    echo "Erreur: Données manquantes.";
    exit();
}

$stmt = $conn->prepare("SELECT numero_place, id_place, etat FROM place WHERE numero_place != '' AND id_park = ?");
$stmt->bind_param("i", $id_park);
$stmt->execute();
$result_places = $stmt->get_result();
while ($row = $result_places->fetch_assoc()) {
    $places_base[strtoupper($row['numero_place'])] = [
        'id' => $row['id_place'],
        'etat_base' => $row['etat']
    ];
}



// Récupérer les places déjà réservées à cette date et heures pour ce parking
$places_occupees = [];
$sql = "SELECT p.numero_place
        FROM réservation r
        JOIN place p ON r.id_place = p.id_place
        WHERE r.date_reserv = ?
        AND p.id_park = ?
        AND (
            (r.heure_entree <= ? AND r.heure_sortie > ?) OR
            (r.heure_entree < ? AND r.heure_sortie >= ?) OR
            (r.heure_entree >= ? AND r.heure_sortie <= ?)
        )";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sissssss", $date_reservation, $id_park, $heure_entree, $heure_entree, $heure_sortie, $heure_sortie, $heure_entree, $heure_sortie);

$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $places_occupees[] = strtoupper($row['numero_place']);
}
$stmt->close();

// Générer la liste des places (option 1 : places fixes A1 à C4)
//$alphabet = ['A', 'B', 'C'];
//$numeros = [1, 2, 3, 4];
//$ordre_places = [];

//foreach ($alphabet as $lettre) {
  //  foreach ($numeros as $numero) {
    //    $ordre_places[] = $lettre . $numero;
    //}
//}
// Générer le HTML
$plan_html = '<div class="parking">';
foreach (array_keys($places_base) as $place_code) {
    $etat_classe = 'empty';
    $icon = '';

    if (isset($places_base[$place_code])) {
        $etat_classe_base = $places_base[$place_code]['etat_base'];
        if (in_array($place_code, $places_occupees)) {
            $etat_classe = 'occupied';
        } else {
            $etat_classe = $etat_classe_base;
        }

        if ($etat_classe_base === 'handicapé') $icon = '♿';
        elseif ($etat_classe_base === 'moto') $icon = '🏍️';
        elseif ($etat_classe_base === 'voiture') $icon = '🚙';
    }

    $plan_html .= "<div class='place $etat_classe' data-place='" . htmlspecialchars($place_code) . "'>" . htmlspecialchars($place_code) . "<br>$icon</div>";
}
$plan_html .= '</div>';

echo $plan_html;
$conn->close();
?>
