<?php
session_start(); // Démarrer la session

// Connexion à la base de données
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "parkigdena";   

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Vérifier les champs
if (empty($_POST['role']) || empty($_POST['mail']) || empty($_POST['password'])) {
    $_SESSION['message'] = "Veuillez remplir tous les champs.";
    header("Location: index.php#seconnecter");
    exit();
}

$role = $_POST['role'];
$email = trim($_POST['mail']);
$motdepasse = trim($_POST['password']);

if ($role === "client") {
    $stmt = $conn->prepare("SELECT mdp_cl FROM client WHERE email_cl = ?");
} elseif ($role === "responsable") {
    $stmt = $conn->prepare("SELECT mdp_respo FROM responsable WHERE email_respo = ?");
} else {
    $_SESSION['message'] = "Rôle non reconnu.";
    header("Location: index.php#seconnecter");
    exit();
}

$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

// Vérification du mot de passe
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
   $password_db = ($role === "client") ? $row['mdp_cl'] : $row['mdp_respo'];


    if ($motdepasse === $password_db) {
        $_SESSION['utilisateur'] = $email;
        $_SESSION['role'] = $role;

        // Redirection selon le rôle
        if ($role === "client") {
            header("Location: Chercher_parking.php");
        } else {
            header("Location: responsable.php"); // ou autre page admin
        }
        exit();
    } else {
        $_SESSION['message'] = "Mot de passe incorrect.";
    }
} else {
    $_SESSION['message'] = "Aucun utilisateur trouvé avec cet email.";
}

$stmt->close();
$conn->close();

header("Location: index.php#seconnecter");
exit();
?>
