  <?php
session_start();

// Connexion à la base
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "parkigdena";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Vérification de la session
if (!isset($_SESSION['utilisateur'])) {
    header("Location: index.php#seconnecter");
    exit();
}

$message = "";

// Récupération de l'ID du client via email
$email_client = $_SESSION['utilisateur'];
$requete_utilisateur = "SELECT id_cl FROM client WHERE email_cl = ?";
$stmt_utilisateur = $conn->prepare($requete_utilisateur);
$stmt_utilisateur->bind_param("s", $email_client);
$stmt_utilisateur->execute();
$result_utilisateur = $stmt_utilisateur->get_result();
$row_utilisateur = $result_utilisateur->fetch_assoc();
$id_client = $row_utilisateur['id_cl'] ?? null;

if (!$id_client) {
    die("Utilisateur introuvable.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_reserv'], $_POST['action'])) {
    $id_reservation = $_POST['id_reserv'];
    $action = $_POST['action'];

    if ($action === 'annuler') {
        $sql = "DELETE FROM réservation WHERE id_reserv = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id_reservation);
        if ($stmt->execute()) {
            $message = "La réservation a été annulée avec succès.";
        } else {
            $message = "Erreur lors de l'annulation.";
        }

    } elseif ($action === 'prolonger') {
        // Récupérer heure_sortie et id_place
        $sql = "SELECT heure_sortie, id_place, date_reserv FROM réservation WHERE id_reserv = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id_reservation);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        if ($row) {
            $heure_sortie = $row['heure_sortie'];
            $date_reserv = $row['date_reserv'];
            $id_place = $row['id_place'];

            $heure_sortie_datetime = new DateTime($heure_sortie);
            $nouvelle_heure_datetime = clone $heure_sortie_datetime;
            $nouvelle_heure_datetime->modify('+2 hour'); // Prolonger de 2 heures
            $nouvelle_heure_sortie = $nouvelle_heure_datetime->format('H:i:s');

            // Vérification de la disponibilité
            $sql_check = "SELECT * FROM réservation 
                          WHERE id_place = ? 
                          AND date_reserv = ?
                          AND heure_entree < ?
                          AND heure_sortie > ?";
            $stmt_check = $conn->prepare($sql_check);
            $stmt_check->bind_param("isss", $id_place, $date_reserv, $nouvelle_heure_sortie, $heure_sortie);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();

            if ($result_check->num_rows === 0) {
                // Aucune réservation conflictuelle, on peut prolonger
                $sql_update = "UPDATE réservation SET heure_sortie = ? WHERE id_reserv = ?";
                $stmt_update = $conn->prepare($sql_update);
                $stmt_update->bind_param("si", $nouvelle_heure_sortie, $id_reservation);

                if ($stmt_update->execute()) {
                    $message = "La réservation a été prolongée jusqu'à " . $nouvelle_heure_sortie . ".";
                } else {
                    $message = "Erreur lors de la prolongation.";
                }
            } else {
                $message = "Impossible de prolonger. La place est déjà réservée après votre créneau actuel.";
            }
        } else {
            $message = "Réservation non trouvée.";
        }
    }
}

// Récupérer toutes les réservations du client
$sql = "SELECT r.*, p.numero_place 
        FROM réservation r
        JOIN place p ON r.id_place = p.id_place
        WHERE r.id_cl = ?
        ORDER BY r.date_reserv DESC, r.heure_entree DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_client);
$stmt->execute();
$result_reservations = $stmt->get_result();

$today = date('Y-m-d');
$now = date('H:i');

$reservations_a_venir = [];
$anciennes_reservations = [];

while ($row = $result_reservations->fetch_assoc()) {
    if ($row['date_reserv'] > $today || ($row['date_reserv'] == $today && $row['heure_sortie'] >= $now)) {
        $reservations_a_venir[] = $row;
    } else {
        $anciennes_reservations[] = $row;
    }
}
?>
  <!DOCTYPE html>
  <html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

    

    <title>Modifier votre profil</title>
    <style>
      * {
        box-sizing: border-box;
      }
      body {
            margin: 0;
            padding: 0;
            font-family: 'Open Sans', sans-serif;
            background: url('image/park.png') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
            animation: zoomBg 18s infinite alternate ease-in-out;
        }
 @keyframes zoomBg {
            from { background-size: 100%; }
            to { background-size: 110%; }
        }
        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.7); /* noir transparent */
            z-index: -1;
        }
        .navbar {
    background-color: rgba(13, 20, 16, 0.7);
    padding: 15px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
}

.welcome {
    color: white;
    font-family: 'Open Sans', sans-serif;
    font-size: 1.4rem;
    animation: fadeSlideIn 1.5s ease-out;
    display: flex;
    align-items: center; /* Centrer verticalement le texte */
    text-decoration: none;
            font-weight: bold;
}
.user-photo {
    width: 50px;  /* Largeur du logo */
    height: 50px; /* Hauteur du logo */
    margin-right: 10px; /* Espacement entre le logo et le texte */
    object-fit: contain; /* Assurer que le logo garde ses proportions */
    border-radius: 50%; /* Si tu veux un logo rond */
}
 
        

         .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            font-size: 1.2rem;
            padding: 8px 16px;
            border-radius: 8px;
            transition: background 0.3s;
            font-family: 'Open Sans', sans-serif;
            font-size: auto;
            animation: fadeSlideIn 1.5s ease-out;
        }

        .nav-links a:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

      .container {
        width: 1000px;
        max-width: 100%;
        background: white;
        border-radius: 15px;
        display: flex;
        overflow: hidden;
        box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        animation: fadeIn 0.8s ease-out both;
      }
      
      .sidebar h2 {
        margin-bottom: 40px;
      }
      .sidebar img {
        width: 200px;
        margin-bottom: 30px;
        margin-top: -30px;
      }
      .steps {
        list-style: none;
        padding: 0;
      }
      .steps li {
        margin-bottom: 20px;
      }
      .steps li a {
        color: #1a5e63;
        text-decoration: none;
        font-weight: bold;
      }
      .main-content {
        flex: 1;
        padding: 40px;
        background-color: #ffffff;
      }
      .main-content    {
        color: #1a5e63;
        margin-bottom: 20px;
      }
      .titre-anciennes {
    color:rgb(97, 119, 241); /* Par exemple un rouge foncé */
    /* ou la couleur que tu veux */
}

      .reservation {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: #e8f8f5;
        border: 1px solid #d1f2eb;
        border-radius: 10px;
        padding: 15px 20px;
        margin-bottom: 15px;
      }
      .reservation.ancienne {
        background: #f2f2f2;
        border-color: #ddd;
      }
      .reservation .details {
        font-weight: 500;
        color: #333;
      }
      .badge {
  padding: 8px 12px;
  border: none;
  cursor: pointer;
  font-weight: bold;
  border-radius: 4px;
  font-size: 14px;
}

/* Bouton rouge */
.btn-rouge {
  background-color: #e74c3c; /* rouge vif */
  color: white;
}

/* Bouton beige */
.btn-beige {
  background-color:rgb(66, 230, 37); /* beige clair */
  color: white;
}

/* Optionnel : effet au survol */
.btn-rouge:hover {
  background-color: #c0392b;
}

.btn-beige:hover {
  background-color:rgb(197, 246, 179);
}
      .reservation.ancienne .badge {
        background-color: gray;
        cursor: default;
      }
      .sidebar-link {
    display: inline-flex;
    align-items: center;
    color: #1a5e63;
    text-decoration: none;
    font-weight: bold;
    margin-top: 20px;
    font-size: 16px;
    transition: color 0.3s;
  }
  .sidebar-link i {
    margin-right: 8px;
    font-size: 18px;
  }
  .sidebar-link:hover {
    color: #17a589;
  }

      @keyframes fadeIn {
        from {
          opacity: 0;
          transform: translateY(20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }
    </style>
  </head>
 
  <body>
<div class = "navbar">
    <div class="welcome">
        <img src="image/logo1.png" alt="Avatar" class="user-photo">Bienvenue dans votre espace !
    </div>

    <div class="nav-links">
      
        <a href="Chercher_parking.php"><i class="fas fa-search"></i>Chercher et Réserver!</a>
        <a href="update.php"><i class="fas fa-user-edit"></i> Modifier mon profil</a>
        <a href="avis.php"><i class="fas fa-star"></i> Donner un avis</a>
        <a href="index.php"><i class="fas fa-sign-out-alt"></i> Se déconnecter</a>
    </div>
</div>

<div class="container">
  <div class="sidebar">
    
  
  </div>
  
<div class="main-content">
    <h2>Mes Réservations à venir</h2>
    <?php if (!empty($message)): ?>
        <p style="color: green; font-weight: bold;"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>

    <?php if (!empty($reservations_a_venir)): ?>
        <?php foreach ($reservations_a_venir as $row): ?>
            <div class="reservation">
                <div class="details">
                    Place <?= htmlspecialchars($row['numero_place']) ?> - <?= htmlspecialchars($row['date_reserv']) ?> - <?= htmlspecialchars($row['heure_entree']) ?> à <?= htmlspecialchars($row['heure_sortie']) ?>
                </div>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="id_reserv" value="<?= htmlspecialchars($row['id_reserv']) ?>">
                    <button type="submit" name="action" value="annuler" class="badge btn-rouge" onclick="return confirm('Êtes-vous sûr de vouloir annuler cette réservation ?');">Annuler</button>
                    <button type="submit" name="action" value="prolonger" class="badge btn-beige" onclick="return confirm('Êtes-vous sûr de vouloir prolonger cette réservation ?');">Prolonger</button>
                </form>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Aucune réservation à venir.</p>
    <?php endif; ?>

    <h2>Anciennes Réservations</h2>
    <?php if (!empty($anciennes_reservations)): ?>
        <?php foreach ($anciennes_reservations as $row): ?>
            <div class="reservation ancienne">
                <div class="details">
                    Place <?= htmlspecialchars($row['numero_place']) ?> - <?= htmlspecialchars($row['date_reserv']) ?> - <?= htmlspecialchars($row['heure_entree']) ?> à <?= htmlspecialchars($row['heure_sortie']) ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Aucune ancienne réservation.</p>
    <?php endif; ?>
</div>
</body>
</html>