<?php
session_start();


// Connexion à la base
require_once("connexion.php");

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['utilisateur'])) {
    header("Location: index.php#seconnecter");
    exit();
}

$nom_client = $_SESSION['utilisateur'];

$places = [];

if (!isset($_GET['id_park'])) {
    echo "Aucun parking sélectionné.";
    exit;
}

$id_park = $_GET['id_park'];

// Récupérer les infos du parking sélectionné
$stmt = $conn->prepare("SELECT * FROM parking WHERE id_park = ?");
$stmt->bind_param("i", $id_park);
$stmt->execute();
$parking = $stmt->get_result()->fetch_assoc();

// Récupérer les places associées à ce parking
$stmt_places = $conn->prepare("SELECT numero_place, etat FROM place WHERE id_park = ?");
$stmt_places->bind_param("i", $id_park);
$stmt_places->execute();
$result = $stmt_places->get_result();

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $places[strtoupper($row['numero_place'])] = $row['etat'];
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenue</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  
    
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Open Sans', sans-serif;
            background: url("image/park.png") no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }
        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: -1;
        }
        .navbar {
            background-color: rgba(13, 20, 16, 0.7);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        .welcome {
            color: white;
            font-family: 'Open Sans', sans-serif;
            font-size: 1.4rem;
            animation: fadeSlideIn 1.5s ease-out;
            display: flex;
            align-items: center;
            text-decoration: none;
            font-weight: bold;
        }
        .user-photo {
            width: 50px;
            height: 50px;
            margin-right: 10px;
            object-fit: contain;
            border-radius: 50%;
        }
        .nav-links {
            display: flex;
            gap: 30px;
            font-family: 'Open Sans', sans-serif;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            font-size: 1.2rem;
            padding: 8px 16px;
            border-radius: 8px;
            transition: background 0.3s;
            font-family: 'Open Sans', sans-serif;
            font-size: auto;
            animation: fadeSlideIn 1.5s ease-out;
        }
        .nav-links a:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }
        .reservation-form {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            width: 80%;
            max-width: 1200px;
        }
        .reservation-form .form-left {
            width: 48%;
        }
        .reservation-form .form-right {
            width: 48%;
            text-align: center;
        }
        .reservation-form h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .reservation-form label {
            display: block;
            margin: 10px 0 5px;
            color: #333;
        }
        .reservation-form input {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .reservation-form button {
            background-color: #007BFF;
            color: white;
            padding: 10px 10px;
            border: none;
            border-radius: 50px;
            margin: 10px 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 1.1rem;
        }
        .reservation-form button:hover {
            background-color: #0056b3;
        }
        .reservation-form .consult {
            background-color:rgb(8, 121, 34);
        }
        .reservation-form .consult:hover {
            background-color: #218838;
        }
        @keyframes fadeSlideIn {
            from {
                opacity: 0;
                transform: translateX(-30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        .parking {
            display: grid;
            grid-template-columns: repeat(4, 80px);
            gap: 10px;
            margin-top: 30px;
            padding: 20px;
            border-radius: 10px;
            width: max-content;
            margin-left: auto;
            margin-right: auto;
        }
        .place {
            padding: 20px;
            text-align: center;
            font-weight: bold;
            color: green;
            border: 2px solid green;
            border-radius: 6px;
            background-color:rgb(237, 254, 241);
        }
        .place i {
            display: block;
            font-size: 24px;
            margin-top: 5px;
        }
        .empty {
            background-color: #cccccc;
        }
        
.place.occupied {
    background-color: red;
    color: white;
    pointer-events: none;
    cursor: not-allowed;
    opacity: 0.8;
    border: 2px red;
}
.facture {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    margin-top: 20px;
}

.facture h2 {
    color: #2c3e50;
    margin-top: 0;
    border-bottom: 1px solid #eee;
    padding-bottom: 10px;
}

.facture h3 {
    color: #34495e;
    margin-bottom: 15px;
}

.facture p {
    margin: 8px 0;
}

.facture-buttons {
    display: flex;
    gap: 10px;
    margin-top: 20px;
}

.btn-print {
    background: #3498db;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 4px;
    cursor: pointer;
}

.btn-new {
    background: #2ecc71;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 4px;
    cursor: pointer;
}

.error {
    color: #e74c3c;
    background: #fadbd8;
    padding: 15px;
    border-radius: 4px;
    margin-top: 20px;
}

    </style>
</head>
<body>

<div class = "navbar">
    <div class="welcome">
        <img src="image/logo1.png" alt="Avatar" class="user-photo">Bienvenue dans votre espace !
    </div>
    <div class="nav-links">
         
         <a href="voir.php"><i class="fa-solid fa-history"></i>Mes réservations</a>
       <a href="update.php"><i class="fas fa-user-edit"></i> Modifier mon profil</a>
        <a href="avis.php"><i class="fas fa-star"></i> Donner un avis</a>
        <a href="index.php"><i class="fas fa-sign-out-alt"></i> Se déconnecter</a>
    </div>
</div>

<form class="reservation-form" id="form_recherche_disponibilite" method="POST">
    <div class="form-left">
        <h2>Réserver une place</h2>
        <label for="date">Date:</label>
       <input type="date" id="date" name="date" min="<?php echo date('Y-m-d'); ?>" required>

        <label for="entry-time">Heure d'entrée :</label>
        <input type="time" id="entry-time" name="entry-time" min="07:00" max="23:00" required>

        <label for="exit-time">Heure de sortie :</label>
        <input type="time" id="exit-time" name="exit-time" min="07:00" max="23:00" required>

        <button type="submit" name="rechercher">Rechercher</button>
        <button type="reset">Annuler</button>
    </div>

    <div class="form-right">
        <div class="mall-indicator">
            <div class="logo-container">
                
            </div>
        </div>
        <div id="plan_parking" class="parking">
        
        <?php
foreach (array_keys($places) as $place) {
    $etat = $places[$place];
    $icon = '';
    if ($etat === 'handicapé') {
        $icon = '♿';
    } elseif ($etat === 'moto') {
        $icon = '🏍️';
    } elseif ($etat === 'voiture') {
        $icon = '🚙';
    }
    echo "<div class='place $etat'>$place<br>$icon</div>";
}
?>

        </div>
        <div id="confirmation_reservation" style="margin-top: 10px;"></div>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const formRecherche = document.getElementById('form_recherche_disponibilite');
    const planParkingDiv = document.getElementById('plan_parking');
    const confirmationReservationDiv = document.getElementById('confirmation_reservation');
    let placeSelectionnee = null;
    const idPark = <?php echo json_encode($_GET['id_park']); ?>; // Récupérer l'id_park côté client

    formRecherche.addEventListener('submit', function(event) {
        event.preventDefault(); // Empêcher la soumission classique du formulaire

        const formData = new FormData(formRecherche);
        formData.append('id_park', idPark); // Ajouter l'id_park aux données

        fetch('verifier_disponibilite.php', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest' // Indique que c'est une requête AJAX
            }
        })
        .then(response => response.text())
        .then(data => {
            planParkingDiv.innerHTML = data; // Afficher le plan du parking reçu

            // Ajouter les écouteurs d'événements aux places après l'affichage
            const places = planParkingDiv.querySelectorAll('.parking .place:not(.empty)');
            places.forEach(placeElement => {
                placeElement.addEventListener('click', function() {
                    const placeCode = this.dataset.place;
                    if (!this.classList.contains('occupied')) {
                        placeSelectionnee = placeCode;
                        confirmationReservationDiv.innerHTML = `Veuillez confirmer votre réservation pour la place ${placeCode} ? <button id="bouton_confirmer_reservation">Oui</button>`;

                        const boutonConfirmer = document.getElementById('bouton_confirmer_reservation');
                        if (boutonConfirmer) {
                            boutonConfirmer.addEventListener('click', function() {
                                if (placeSelectionnee) {
                                    const dateReservation = document.getElementById('date').value;
                                    const heureEntree = document.getElementById('entry-time').value;
                                    const heureSortie = document.getElementById('exit-time').value;
                                  // ... (le code précédent reste identique jusqu'au fetch de reserver_place.php)

fetch('reserver_place.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest'
    },
    body: `place_choisie=${encodeURIComponent(placeSelectionnee)}&date=${encodeURIComponent(dateReservation)}&entry-time=${encodeURIComponent(heureEntree)}&exit-time=${encodeURIComponent(heureSortie)}&id_park=${encodeURIComponent(idPark)}`
})
.then(response => {
    if (!response.ok) {
        throw new Error('Erreur réseau');
    }
    return response.json();
})
.then(data => {
    if(data.success) {
        // Calcul de la durée
        const debut = new Date(`${dateReservation}T${heureEntree}`);
        const fin = new Date(`${dateReservation}T${heureSortie}`);
        const dureeMs = fin - debut;
        const dureeHeures = Math.round((dureeMs / (1000 * 60 * 60)) * 100) / 100;
        
        // Afficher la facture
       confirmationReservationDiv.innerHTML = `
    <div class="success">
        <h2>Réservation confirmée !</h2>
        <p>Votre réservation pour la place <strong>${placeSelectionnee}</strong> a été enregistrée.</p>
        <a href="facture.php?id_reserv=${data.id_reserv}" target="_blank" class="btn-facture">Voir la facture</a>
    </div>`;

        
        // Recharger les disponibilités
        formRecherche.dispatchEvent(new Event('submit'));
    } else {
        confirmationReservationDiv.innerHTML = `<div class="error">${data.message}</div>`;
    }
})
.catch(error => {
    console.error('Erreur:', error);
    confirmationReservationDiv.innerHTML = '<div class="error">Erreur lors de la réservation</div>';
});

// ... (le reste de votre code)
                                }
                            });
                        }
                    }
                });
            });
        })
        .catch(error => {
            console.error('Erreur lors de la récupération du plan:', error);
            planParkingDiv.innerHTML = 'Erreur lors du chargement du plan du parking.';
        });
    });

    // Code pour la restriction de la date (semaine actuelle)
    /*function getWeekStartAndEnd() {
        const today = new Date();
        const dayOfWeek = today.getDay();
        const startOfWeek = new Date(today);
        startOfWeek.setDate(today.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1)); // Lundi
        const endOfWeek = new Date(startOfWeek);
        endOfWeek.setDate(startOfWeek.getDate() + 6); // Dimanche
        return { startOfWeek, endOfWeek };
    }

    function formatDateForInput(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
*/
    function setDateRestrictions() {
        const { startOfWeek, endOfWeek } = getWeekStartAndEnd();
        const dateInput = document.getElementById('date');
        dateInput.setAttribute('min', formatDateForInput(startOfWeek));
        dateInput.setAttribute('max', formatDateForInput(endOfWeek));
    }

    setDateRestrictions();
});

</script>

</body>
</html>