<?php
session_start();
require_once('PHPMailer/PHPMailer.php');
require_once('PHPMailer/SMTP.php');
require_once('PHPMailer/Exception.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;



include("connexion.php");


if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    header("HTTP/1.0 403 Forbidden");
    exit();
}

$id_park = $_POST['id_park'] ?? null;
if (!$id_park) {
    echo "Erreur: ID du parking non spécifié.";
    exit();
}

if (!isset($_SESSION['utilisateur'])) {
    echo "Erreur: Utilisateur non connecté.";
    exit();
}
$place_choisie = $_POST['place_choisie'] ?? null;
$date_reservation = $_POST['date'] ?? null;
$heure_entree = $_POST['entry-time'] ?? null;
$heure_sortie = $_POST['exit-time'] ?? null;
$nom_utilisateur = $_SESSION['utilisateur'];

if (!$place_choisie || !$date_reservation || !$heure_entree || !$heure_sortie) {
    echo "Erreur: Veuillez fournir toutes les informations de réservation.";
    exit();
}

$requete_utilisateur = "SELECT id_cl, email_cl FROM client WHERE email_cl = ?";
$stmt_utilisateur = $conn->prepare($requete_utilisateur);
$stmt_utilisateur->bind_param("s", $nom_utilisateur);
$stmt_utilisateur->execute();
$result_utilisateur = $stmt_utilisateur->get_result();
if ($result_utilisateur->num_rows !== 1) {
    echo "Erreur: Utilisateur introuvable.";
    $stmt_utilisateur->close();
    $conn->close();
    exit();
}
$row_utilisateur = $result_utilisateur->fetch_assoc();
$id_utilisateur = $row_utilisateur['id_cl'];
$email_utilisateur = $row_utilisateur['email_cl']; // Récupérer l'e-mail
$stmt_utilisateur->close();

$requete_place = "SELECT id_place FROM place WHERE numero_place = ? AND id_park = ?";
$stmt_place = $conn->prepare($requete_place);
$stmt_place->bind_param("si", $place_choisie, $id_park);
$stmt_place->execute();
$result_place = $stmt_place->get_result();
if ($result_place->num_rows !== 1) {
    echo "Erreur: Place introuvable dans ce parking.";
    $stmt_place->close();
    $conn->close();
    exit();
}
$row_place = $result_place->fetch_assoc();
$id_place = $row_place['id_place'];
$stmt_place->close();

$requete_verif = "SELECT id_reserv FROM réservation
                    WHERE id_place = ? AND date_reserv = ? AND id_park = ?
                      AND (
                           (heure_entree <= ? AND heure_sortie > ?) OR
                           (heure_entree < ? AND heure_sortie >= ?) OR
                           (heure_entree >= ? AND heure_sortie <= ?)
                       )";
$stmt_verif = $conn->prepare($requete_verif);
$stmt_verif->bind_param("iississss", $id_place, $date_reservation, $id_park, $heure_entree, $heure_entree, $heure_sortie, $heure_sortie, $heure_entree, $heure_sortie);
$stmt_verif->execute();
$result_verif = $stmt_verif->get_result();

if ($result_verif->num_rows > 0) {
    echo "Erreur: Cette place est déjà réservée pour cette période dans ce parking.";
    $stmt_verif->close();
    $conn->close();
    exit();
}
$stmt_verif->close();

// Récupérer le nom du parking
$requete_nom_parking = "SELECT nom_park FROM parking WHERE id_park = ?";
$stmt_nom_parking = $conn->prepare($requete_nom_parking);
$stmt_nom_parking->bind_param("i", $id_park);
$stmt_nom_parking->execute();
$result_nom_parking = $stmt_nom_parking->get_result();
$nom_du_parking = "";
if ($result_nom_parking->num_rows === 1) {
    $row_nom_parking = $result_nom_parking->fetch_assoc();
    $nom_du_parking = htmlspecialchars($row_nom_parking['nom_park']);
}
$stmt_nom_parking->close();

// Générer le code d'entrée **AVANT** l'insertion
function genererCodeEntreeAlphaNumeriqueSimple($longueur = 7) {
    $caracteres = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789'; // Omission de 'I', 'l', 'o' pour éviter la confusion
    $code = '';
    $max = strlen($caracteres) - 1;
    for ($i = 0; $i < $longueur; $i++) {
        $code .= $caracteres[random_int(0, $max)];
    }
    return $code;
}

$code_entree = genererCodeEntreeAlphaNumeriqueSimple();

// Insérer la réservation dans la base de données **AVEC** le code d'entrée
$requete_insertion = "INSERT INTO réservation (id_place, id_cl, id_park, date_reserv, heure_entree, heure_sortie, code_entree)
                        VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt_insertion = $conn->prepare($requete_insertion);
$stmt_insertion->bind_param("iiissss", $id_place, $id_utilisateur, $id_park, $date_reservation, $heure_entree, $heure_sortie, $code_entree);

// ... (le code existant reste le même jusqu'à la partie d'insertion)

if ($stmt_insertion->execute()) {
    $id_reserv = $conn->insert_id; // Récupérer l'ID de la nouvelle réservation
    
    // Préparer la réponse JSON
    $response = [
        'success' => true,
        'message' => "Réservation confirmée avec succès pour la place " . htmlspecialchars($place_choisie),
        'id_reserv' => $id_reserv,
        'code_entree' => $code_entree,
        'parking' => $nom_du_parking,
        'date' => $date_reservation,
        'heure_entree' => $heure_entree,
        'heure_sortie' => $heure_sortie
    ];
    
    // Envoi de l'email (votre code existant)
    try {
        $mail = new PHPMailer(true);
        // ... (votre configuration PHPMailer)
        $mail->send();
    } catch (Exception $e) {
        error_log("Erreur envoi e-mail: {$mail->ErrorInfo}");
        // On ne bloque pas le processus si l'email échoue
        $response['email_sent'] = false;
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    
} else {
    echo json_encode([
        'success' => false,
        'message' => "Erreur lors de l'enregistrement de la réservation"
    ]);
}
$stmt_insertion->close();
$conn->close();
?>