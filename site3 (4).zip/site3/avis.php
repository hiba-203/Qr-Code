<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "parkigdena";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Vérifie que le client est connecté
if (!isset($_SESSION['utilisateur'])) {
    header("Location: index.php#seconnecter");
    exit();
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['envoyer'])) {
    $msg = $conn->real_escape_string(trim($_POST['msg']));
    $rating = intval($_POST['rating']); // récupère la note
    $email = $_SESSION['utilisateur'];

    if (!empty($msg)) {
        $sqlUser = "SELECT id_cl FROM client WHERE email_cl = ?";
        $stmt = $conn->prepare($sqlUser);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            $id_client = $user['id_cl'];

            // Ajoute la note ici dans la requête
            $sqlInsert = "INSERT INTO avis (id_cl, message, note) VALUES (?, ?, ?)";
            $stmtInsert = $conn->prepare($sqlInsert);
            $stmtInsert->bind_param("isi", $id_client, $msg, $rating);

            if ($stmtInsert->execute()) {
                $message = "Merci pour votre avis ❤️";
            } else {
                $message = "Erreur lors de l'enregistrement de votre avis.";
            }

            $stmtInsert->close();
        } else {
            $message = "Utilisateur non trouvé.";
        }

        $stmt->close();
    } else {
        $message = "Le message ne peut pas être vide.";
    }
}


$conn->close();
?>





<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    
    
  <title>Modifier votre profil</title>
  <style>
    * {
      box-sizing: border-box;
    }
    body {
            margin: 0;
            padding: 0;
            font-family: 'Open Sans', sans-serif;
            background: url('image/park.png') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
            animation: zoomBg 18s infinite alternate ease-in-out;
        }
         @keyframes zoomBg {
            from { background-size: 100%; }
            to { background-size: 110%; }
        }

        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.7); /* noir transparent */
            z-index: -1;
        }
        .navbar {
    background-color: rgba(13, 20, 16, 0.7);
    padding: 15px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
}

.welcome {
    color: white;
    font-family: 'Open Sans', sans-serif;
    font-size: 1.5rem;
    animation: fadeSlideIn 1.5s ease-out;
    display: flex;
    align-items: center; /* Centrer verticalement le texte */
    text-decoration: none;
            font-weight: bold;
}

.user-photo {
    width: 50px;  /* Largeur du logo */
    height: 50px; /* Hauteur du logo */
    margin-right: 10px; /* Espacement entre le logo et le texte */
    object-fit: contain; /* Assurer que le logo garde ses proportions */
    border-radius: 50%; /* Si tu veux un logo rond */
}
.nav-links {
            display: flex;
            gap: 30px;
            font-family: 'Open Sans', sans-serif;
            
        }

         .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            font-size: 1.2rem;
            padding: 8px 16px;
            border-radius: 8px;
            transition: background 0.3s;
            font-family: 'Open Sans', sans-serif;
            font-size: auto;
            animation: fadeSlideIn 1.5s ease-out;
        }

        .nav-links a:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }
    .container {
      max-width: 900px;
      margin: 40px auto;
      background: white;
      border-radius: 15px;
      display: flex;
      overflow: hidden;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }
    
    .sidebar h2 {
      margin-bottom: 40px;
    }
    .sidebar img {
        width: 200px;
        margin-bottom: 30px;
        margin-top: -30px;
      }
   
    .form-section {
      flex: 1;
      padding: 40px;
      
    }
    .form-section h3 {
      margin-top: 0;
      color: #F33A6A;
    }
    .form-group {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      margin-bottom: 20px;
      flex-direction: column;
    }
    .form-group label {
      font-weight: bold;
      color: #444;
      
    }
    .form-control {
  width: 100%;
  min-height: 120px; /* hauteur initiale */
  resize: vertical; /* pour qu’il puisse agrandir le champ verticalement */
  padding: 10px;
  font-size: 16px;
}


    .half {
      flex: 1 1 48%;
    }
    .third {
      flex: 1 1 30%;
    }
    .btn-next {
      background: #20c997;
      color: white;
      padding: 12px 25px;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      margin-right: 10px;
    }
    .btn-next:hover {
      background: #17a589;
    }
    .btn-reset {
      background: rgb(248, 48, 88);
      color: white;
      padding: 12px 25px;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
    }
    .btn-reset:hover {
      background: rgb(248, 107, 107);
    }
    .text-danger {
      color: red;
      font-size: 13px;
    }
    .alert {
      background: #d4edda;
      color: #155724;
      padding: 10px 15px;
      border-radius: 5px;
      margin-bottom: 20px;
    }
    /* Animation de fade-in */
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px); /* ou X pour un slide horizontal */
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
@keyframes fadeSlideIn {
            from {
                opacity: 0;
                transform: translateX(-30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }


/* Appliquer l'animation au conteneur principal */
.container {
  animation: fadeIn 0.8s ease-out both;
}

.rating .star {
  font-size: 2rem;
  color: #ccc;
  cursor: pointer;
}
.rating .star.active {
  color: gold;
}

  </style>
</head>
<body>
<div class = "navbar">
    <div class="welcome">
        <img src="image/logo1.png" alt="Avatar" class="user-photo">Bienvenue dans votre espace !
    </div>
    <div class="nav-links">
       <a href="voir.php"><i class="fa-solid fa-history"></i>Mes réservations</a>
        <a href="update.php"><i class="fas fa-user-edit"></i> Modifier mon profil</a>
        <a href="Chercher_parking.php"><i class="fas fa-search"></i>Chercher et Réserver!</a>
        <a href="index.php"><i class="fas fa-sign-out-alt"></i> Se déconnecter</a>
        
    </div>
</div>

<div class="container">
  <div class="sidebar">
  </div>

  


      <div class="form-section">
  <h3>Votre opinion compte beaucoup pour nous ❤️</h3>
  <?php if (!empty($message)): ?>
    <div class="alert"><?php echo $message; ?></div>
  <?php endif; ?>

  <form action="" method="POST">

    <!-- Bloc pour le commentaire -->
    <div class="form-group">
      <label>Votre Commentaire</label>
      <textarea name="msg" class="form-control" rows="5" required></textarea>
    </div>

    <!-- Bloc pour l’évaluation par étoiles -->
    <div class="form-group">
      <label for="rating" class="form-label">Votre évaluation</label>
      <div class="rating">
        <span class="star" data-rating="1">★</span>
        <span class="star" data-rating="2">★</span>
        <span class="star" data-rating="3">★</span>
        <span class="star" data-rating="4">★</span>
        <span class="star" data-rating="5">★</span>
      </div>
      <input type="hidden" name="rating" id="rating-value" value="0">
    </div>

    <button type="submit" name="envoyer" class="btn-next">Envoyer</button>
    <button type="reset" class="btn-reset">Annuler</button>
  </form>
</div>


      

      
<script>
  document.addEventListener('DOMContentLoaded', function () {
    const stars = document.querySelectorAll('.rating .star');
    const ratingInput = document.getElementById('rating-value');

    stars.forEach((star, index) => {
      star.addEventListener('click', function () {
        const rating = this.getAttribute('data-rating');
        ratingInput.value = rating;

        stars.forEach(s => s.classList.remove('active'));
        for (let i = 0; i < rating; i++) {
          stars[i].classList.add('active');
        }
      });
    });
  });
</script>


</body>
</html>
