<?php
session_start();
include('connexion.php');
?>
<!DOCTYPE HTML>
<!--
	Dimension by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
<head>
<body class="is-preload">	
		<title>ParkiGdena</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<div id="main">

		<!-- Intro -->
			<article id="Apropos">
				<h2 class="major">A propos</h2>
				<span class="image main"><img src="" alt="" /></span>
				<h3><a href="#work">Bienvenue sur Parkigdena, votre solution de stationnement intelligente !</a>.</h3>
				<p>Charte d'utilisation
Chaque utilisateur a le droit d’effectuer trois réservations par semaine, avec une seule réservation active à la fois par compte. En cas de besoin, l'utilisateur peut modifier l’heure ou la date de sa réservation jusqu'à 12 heures avant l'heure de réservation initiale, au lieu de devoir l’annuler. Une fois ce délai dépassé, seule l'annulation sera possible. Toute annulation ou modification doit être confirmée par l’utilisateur. Seuls les utilisateurs ayant un compte peuvent laisser un avis. Les réservations sont uniquement valables pour la semaine en cours et ne peuvent pas être effectuées pour les semaines ou mois suivants. Les horaires de réservation doivent respecter les heures d’ouverture et de fermeture du mall. Enfin, une seule adresse e-mail est autorisée par compte.

</p>
			</article>