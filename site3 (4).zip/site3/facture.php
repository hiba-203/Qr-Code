<?php
require_once("connexion.php");

$id_reserv = $_GET['id_reserv'] ?? null;

if (!$id_reserv) {
    echo "Réservation invalide.";
    exit();
}

$requete = "SELECT r.*, p.numero_place, cl.email_cl, pk.nom_park, pk.prix
            FROM réservation r
            JOIN place p ON r.id_place = p.id_place
            JOIN client cl ON r.id_cl = cl.id_cl
            JOIN parking pk ON r.id_park = pk.id_park
            WHERE r.id_reserv = ?";

$stmt = $conn->prepare($requete);
$stmt->bind_param("i", $id_reserv);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo "Réservation non trouvée.";
    exit();
}

$row = $result->fetch_assoc();

// Calcul durée
$debut = new DateTime($row['date_reserv'] . ' ' . $row['heure_entree']);
$fin = new DateTime($row['date_reserv'] . ' ' . $row['heure_sortie']);
$duree = $debut->diff($fin);
$dureeHeures = $duree->h + $duree->i / 60;
$tarif = $row['prix'];
$total = round($dureeHeures * $tarif, 2);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Facture de réservation</title>
    <style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f9f9f9;
    margin: 0;
    padding: 30px;
}

.facture {
    max-width: 700px;
    background: #ffffff;
    margin: auto;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 0 15px rgba(0,0,0,0.1);
}

h2, h3 {
    text-align: center;
    color: #2c3e50;
    margin-bottom: 20px;
}

p {
    font-size: 16px;
    line-height: 1.6;
    margin: 8px 0;
    color: #333;
}

strong {
    color: #000;
}

hr {
    margin: 30px 0;
    border: none;
    border-top: 1px solid #ddd;
}

.btn-print {
    margin-top: 30px;
    display: block;
    width: 100%;
    padding: 12px;
    font-size: 16px;
    background: #28a745;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s;
}

.btn-print:hover {
    background: #218838;
}

.logo {
    text-align: left;
    margin-bottom: 20px;
}

.logo img {
    max-height: 60px;
}

.signature {
    text-align: left;
    margin-top: 40px;
}

.signature img {
    max-height: 80px;
}

.footer-legal {
    font-size: 12px;
    color: gray;
    text-align: center;
    margin-top: 15px;
}

    </style>
</head>
<body>
<div class="facture">
    <!-- Logo centré en haut -->
<div class="logo">
    <img src="image/logo1.png" alt="Logo de l'application">
</div>
    <h2>Facture de Réservation</h2>
    <p><strong>Client :</strong> <?= htmlspecialchars($row['email_cl']) ?></p>
    <p><strong>Parking :</strong> <?= htmlspecialchars($row['nom_park']) ?></p>
    <p><strong>Place :</strong> <?= htmlspecialchars($row['numero_place']) ?></p>
    <p><strong>Date :</strong> <?= htmlspecialchars($row['date_reserv']) ?></p>
    <p><strong>Heure d'entrée :</strong> <?= htmlspecialchars($row['heure_entree']) ?></p>
    <p><strong>Heure de sortie :</strong> <?= htmlspecialchars($row['heure_sortie']) ?></p>
    <p><strong>Code d'entrée :</strong> <?= htmlspecialchars($row['code_entree']) ?></p>
    <hr>
    <h3>Détails du paiement</h3>
    <p><strong>Durée :</strong> <?= round($dureeHeures, 2) ?> heures</p>
   <p><strong>Tarif horaire :</strong> <?= $tarif ?> DT</p>
<p><strong>Total :</strong> <?= $total ?> DT</p>
 <div class="signature">
    <img src="image/signature.png" alt="Signature de l'administrateur">
</div>
<p class="footer-legal">
    Cette facture est générée automatiquement et signée électroniquement par l'administration. Toute modification rend ce document invalide.
</p>

    <button onclick="window.print()" class="btn-print">Imprimer</button>

</div>
</body>
</html>
